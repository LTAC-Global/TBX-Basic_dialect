# Min Module Versions

## 1.0 (2018-05-01)
#### [Definition](./TBX_min_module_1.0/Min Module Definition.pdf)
#### [Download](./TBX_min_module_1.0.zip)
